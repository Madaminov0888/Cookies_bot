
from django.shortcuts import render

# Create your views here.
'social media:   Tiktok'
'how often you use it:   actually, i use it almost every day!'
'Advantages:   Learning something and obtain with new information or news'
'Disadvantages:   you can hang up there for a long time'